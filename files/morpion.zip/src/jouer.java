import java.awt.Dimension;
import java.awt.Toolkit;

public class jouer
{

	public static void main(String[] args) 
	{
		morpion morp = new morpion();

		morp.setSize(190,250);
		
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		morp.setLocation((screenSize.width-morp.getWidth())/2,(screenSize.height-morp.getHeight())/2);
		
		morp.setVisible(true);
	}
}