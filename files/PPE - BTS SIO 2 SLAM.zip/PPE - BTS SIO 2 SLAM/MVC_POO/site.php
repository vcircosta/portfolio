<h2> Gestion des sites </h2>

<?php
	$lesClients = $unControleur->selectAllClients ();
	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$leSite = null;
	if (isset($_GET['action']) && isset($_GET['idsite'])){
		$action = $_GET['action'];
		$idsite = $_GET['idsite'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteSite($idsite); break;
			case 'edit': $leSite = $unControleur -> selectWhereSite($idsite);
			break;

		}
	}
	

	require_once ("vue/vue_insert_site.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertSite($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateSite($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesSites = $unControleur -> selectLikeSite($mot);
	}else {
		$lesSites=$unControleur
		->selectAllSites();
	}
	require_once ("vue/vue_les_sites.php");
?>