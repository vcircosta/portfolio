<h2> Bienvenue chez Filelec </h2>

<h4> M./MM. 
    <?=$_SESSION['nom']." ".$_SESSION['prenom'].
    "<br> Vous avez le rôle : ".$_SESSION['role']
?>
</h4>
<img src="images/logo.png" height="400" width="600">

<br/>