<h2> Gestion des devis </h2>

<?php
	$lesClients = $unControleur->selectAllClients ();
	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$leDevis = null;
	if (isset($_GET['action']) && isset($_GET['reference_devis'])){
		$action = $_GET['action'];
		$iddevis = $_GET['reference_devis'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteDevis($iddevis); break;
			case 'edit': $leDevis = $unControleur -> selectWhereDevis($iddevis);
			break;

		}
	}
	

	require_once ("vue/vue_insert_devis.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertDevis($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateDevis($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesDevis = $unControleur -> selectLikeDevis($mot);
	}else {
		$lesDevis = $unControleur->selectAllDevis ();
	}
	require_once ("vue/vue_les_devis.php");
?>