<h2> Gestion des ordres de fabrication </h2>

<?php
	$lesClients = $unControleur->selectAllClients ();
	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$lOrdre_de_Fabrication = null;
	if (isset($_GET['action']) && isset($_GET['num_ordres'])){
		$action = $_GET['action'];
		$idordres_de_fabrication = $_GET['num_ordres'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteOrdre_de_Fabrication($idordres_de_fabrication); break;
			case 'edit': $lOrdre_de_Fabrication = $unControleur -> selectWhereOrdre_de_Fabrication($idordres_de_fabrication);
			break;

		}
	}
	

	require_once ("vue/vue_insert_ordre_de_fabrication.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertOrdre_de_Fabrication($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateOrdre_de_Fabrication($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesOrdres_de_Fabrications = $unControleur ->selectLikeOrdre_de_Fabrication($mot);
	}else {
		$lesOrdres_de_Fabrications = $unControleur->selectAllOrdres_de_Fabrications();
	}
	require_once ("vue/vue_les_ordres_de_fabrications.php");
?>