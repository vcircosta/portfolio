<h2> Gestion des fournisseurs </h2>

<?php

	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$leFournisseur = null;
	if (isset($_GET['action']) && isset($_GET['num_fournisseur'])){
		$action = $_GET['action'];
		$idfournisseur = $_GET['num_fournisseur'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteFournisseur($idfournisseur); break;
			case 'edit': $leFournisseur = $unControleur -> selectWhereFournisseur($idfournisseur);
			break;

		}
	}
	

	require_once ("vue/vue_insert_fournisseur.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertFournisseur($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateFournisseur($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesFournisseurs = $unControleur -> selectLikeFournisseur($mot);
	}else {
		$lesFournisseurs = $unControleur->selectAllFournisseurs ();
	}
	require_once ("vue/vue_les_fournisseurs.php");
?>