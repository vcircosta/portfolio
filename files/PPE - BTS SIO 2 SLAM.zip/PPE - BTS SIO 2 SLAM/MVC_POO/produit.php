<h2> Gestion des produits </h2>

<?php
	$lesTypes_Produits = $unControleur->selectAllTypes_Produits ();
	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$leProduit = null;
	if (isset($_GET['action']) && isset($_GET['ref_prod'])){
		$action = $_GET['action'];
		$idproduit = $_GET['ref_prod'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteProduit($idproduit); break;
			case 'edit': $leProduit = $unControleur -> selectWhereProduit($idproduit);
			break;

		}
	}
	

	require_once ("vue/vue_insert_produit.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertProduit($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateProduit($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesProduits = $unControleur -> selectLikeProduit($mot);
	}else {
		$lesProduits = $unControleur->selectAllProduits ();
	}
	require_once ("vue/vue_les_produits.php");
?>