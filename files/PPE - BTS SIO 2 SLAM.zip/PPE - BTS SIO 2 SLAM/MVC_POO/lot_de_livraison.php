<h2> Gestion des lots de livraisons </h2>

<?php
	$lesDemandes_de_Livraisons = $unControleur->selectAllDemandes_de_Livraisons ();
	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$leLotDeLivraison = null;
	if (isset($_GET['action']) && isset($_GET['numero_lot'])){
		$action = $_GET['action'];
		$idlot_de_livraison = $_GET['numero_lot'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteLot_de_Livraison($idlot_de_livraison); break;
			case 'edit': $leLotDeLivraison = $unControleur -> selectWhereLot_de_Livraison($idlot_de_livraison);
			break;

		}
	}
	

	require_once ("vue/vue_insert_lot_de_livraison.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertLot_de_Livraison($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateLot_de_Livraison($_POST);
	}
}	
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesLots_de_Livraisons = $unControleur -> selectLikeLot_de_Livraison($mot);
	}else {
		$lesLots_de_Livraisons = $unControleur->selectAllLots_de_Livraisons ();
	}
	require_once ("vue/vue_les_lots_de_livraisons.php");
?>