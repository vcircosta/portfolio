<h2>Connexion au site de filelec</h2>
<!--  FORMULAIRE DE CONNEXION   !-->
<form method="post">
    <table>
        <tr>
            <td>Email</td>
            <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <td>MDP</td>
            <td><input type="password" name="mdp"></td>
        </tr>
        <tr>
            <td><input type="reset" name="Annuler" value="Annuler"></td>
            <td><input type="submit" name="seConnecter" value="Connexion"></td>
        </tr>
    </table>
</form>