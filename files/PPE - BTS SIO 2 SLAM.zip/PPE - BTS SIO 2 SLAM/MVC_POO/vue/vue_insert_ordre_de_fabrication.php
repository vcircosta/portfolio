<h3> Ajout d'un ordre de fabrication </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom de l'ordre de fabrication </td>
			<td><input type="text" name="nom" value="<?= ($lOrdre_de_Fabrication !=null) ? $lOrdre_de_Fabrication ['nom'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Le client </td>
			<td>
			<select name="idclient">
				<?php
				foreach($lesClients as $unClient)
				{
					echo "<option value ='".$unClient['idclient']."'>";
					echo $unClient['nom']; 
					echo "</option>"; 
				}
				?>
			</select>

			</td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($lOrdre_de_Fabrication !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="num_ordres" value ="
<?= ($lOrdre_de_Fabrication !=null)? $lOrdre_de_Fabrication['num_ordres'] : '' ?>
">
	</table>
</form>