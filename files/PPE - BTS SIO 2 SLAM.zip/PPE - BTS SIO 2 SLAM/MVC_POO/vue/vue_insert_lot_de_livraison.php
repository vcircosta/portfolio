<h3> Ajout de lot de livraison </h3>
<form method="post">
	<table>
		<tr>
			<td> Quantité du lot </td>
			<td><input type="text" name="quantite_du_lot" 
			value="
			<?= 
			($leLotDeLivraison 
			!=null)
			 ? $leLotDeLivraison ['quantite_du_lot'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Date de fabrication </td>
			<td><input type="text" name="date_de_fabrication"value="<?= ($leLotDeLivraison !=null) ? $leLotDeLivraison ['date_de_fabrication'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Date de départ </td>
			<td><input type="text" name="date_du_depart"value="<?= ($leLotDeLivraison !=null) ? $leLotDeLivraison ['date_du_depart'] : '' ?>"></td>
		</tr>
        <tr>
			<td> Date de livraison </td>
			<td><input type="text" name="date_de_livraison"value="<?= ($leLotDeLivraison !=null) ? $leLotDeLivraison ['date_de_livraison'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Numéro de demande </td>
			<td>
			<select name="num_demande">
				<?php
				foreach($lesDemandes_de_Livraisons as $uneDemande_de_Livraison)
				{
					echo "<option value ='".$uneDemande_de_Livraison['num_demande']."'>";
					echo $uneDemande_de_Livraison['quantite_a_livrer']; 
					echo "</option>"; 
				}
				?>
			</select>

			</td>
		</tr>

		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leLotDeLivraison !=null) ? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="numero_lot" value ="
<?= ($leLotDeLivraison !=null)? $leLotDeLivraison['numero_lot'] : '' ?>
">
	</table>
</form>