
	<h3> Liste des fournisseurs </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Numéro fournisseur </td>
         <td> Nom </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesFournisseurs as $unFournisseur) {
    echo "<tr>";
    echo "<td>".$unFournisseur['num_fournisseur']."</td>";
    echo "<td>".$unFournisseur['nom']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=6&action=sup&num_fournisseur=".$unFournisseur['num_fournisseur']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=6&action=edit&num_fournisseur=".$unFournisseur['num_fournisseur']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>