
	<h3> Liste des produits </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Reference produit </td>
         <td> Caracteristique </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesProduits as $unProduit) {
    echo "<tr>";
    echo "<td>".$unProduit['ref_prod']."</td>";
    echo "<td>".$unProduit['caracteristique']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=10&action=sup&ref_prod=".$unProduit['ref_prod']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=10&action=edit&ref_prod=".$unProduit['ref_prod']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>