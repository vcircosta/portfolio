<h3> Ajout d'un fournisseur </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom du fournisseur </td>
			<td><input type="text" name="nom" value="<?= ($leFournisseur !=null) ? $leFournisseur ['nom'] : '' ?>"></td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leFournisseur !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="num_fournisseur" value ="
<?= ($leFournisseur !=null)? $leFournisseur['num_fournisseur'] : '' ?>
">
	</table>
</form>