<h3> Ajout d'une commande </h3>
<form method="post">
	<table>
		<tr>
			<td> Livraison effective </td>
			<td><input type="text" name="livraison_effective" value="<?= ($laCommande !=null) ? $laCommande ['livraison_effective'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Etat de la commande </td>
			<td><input type="text" name="etat_commande"value="<?= ($laCommande !=null) ? $laCommande ['etat_commande'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Reference devis </td>
			<td>
			<select name="reference_devis">
				<?php
				foreach($lesDevis as $unDevis)
				{
					echo "<option value ='".$unDevis['reference_devis']."'>";
					echo $unDevis['description_devis']; 
					echo "</option>"; 
				}
				?>
			</select>

			</td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($laCommande !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="num_commande" value ="
<?= ($laCommande !=null)? $laCommande['num_commande'] : '' ?>
">
	</table>
</form>