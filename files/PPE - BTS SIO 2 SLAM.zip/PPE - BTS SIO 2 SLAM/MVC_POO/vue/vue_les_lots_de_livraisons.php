
	<h3> Liste des lots de livraisons </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Numéro de lot </td>
         <td> Quantité du lot </td>
         <td> Date de fabrication </td>
         <td> Date du depart </td>
         <td> Date de livraison </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesLots_de_Livraisons as $unLot_de_Livraison) {
    echo "<tr>";
    echo "<td>".$unLot_de_Livraison['numero_lot']."</td>";
    echo "<td>".$unLot_de_Livraison['quantite_du_lot']."</td>";
    echo "<td>".$unLot_de_Livraison['date_de_fabrication']."</td>";
    echo "<td>".$unLot_de_Livraison['date_du_depart']."</td>";
    echo "<td>".$unLot_de_Livraison['date_de_livraison']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=7&action=sup&numero_lot=".$unLot_de_Livraison['numero_lot']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=7&action=edit&numero_lot=".$unLot_de_Livraison['numero_lot']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>