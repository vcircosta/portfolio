
	<h3> Liste des types de produit </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Code type </td>
         <td> Nom type </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesTypes_Produits as $unType_Produit) {
    echo "<tr>";
    echo "<td>".$unType_Produit['code_type']."</td>";
    echo "<td>".$unType_Produit['nom_type']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=12&action=sup&code_type=".$unType_Produit['code_type']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=12&action=edit&code_type=".$unType_Produit['code_type']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>