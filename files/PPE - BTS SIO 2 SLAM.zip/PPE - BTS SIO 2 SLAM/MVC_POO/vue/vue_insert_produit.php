<h3> Ajout d'un produit </h3>
<form method="post">
	<table>
		<tr>
			<td> Caracteristique </td>
			<td><input type="text" name="caracteristique" value="<?= ($leProduit !=null) ? $leProduit ['caracteristique'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Code du type produit </td>
			<td>
			<select name="code_type">
				<?php
				foreach($lesTypes_Produits as $unType_Produit)
				{
					echo "<option value ='".$unType_Produit['code_type']."'>";
					echo $unType_Produit['nom_type']; 
					echo "</option>"; 
				}
				?>
			</select>

			</td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leProduit !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="ref_prod" value ="
<?= ($leProduit !=null)? $leProduit['ref_prod'] : '' ?>
">
	</table>
</form>