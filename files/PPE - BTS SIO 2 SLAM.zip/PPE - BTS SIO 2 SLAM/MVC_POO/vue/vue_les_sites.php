
	<h3> Liste des sites </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Id site </td>
         <td> Code postal </td>
         <td> Ville </td>
         <td> Adresse </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesSites as $unSite) {
    echo "<tr>";
    echo "<td>".$unSite['idsite']."</td>";
    echo "<td>".$unSite['code_postal']."</td>";
    echo "<td>".$unSite['ville']."</td>";
    echo "<td>".$unSite['adresse']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=11&action=sup&idsite=".$unSite['idsite']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=11&action=edit&idsite=".$unSite['idsite']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>