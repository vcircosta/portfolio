
	<h3> Liste des demandes de livraisons </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Numero demande </td>
         <td> Quantite a livrer </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesDemandes_de_Livraisons as $uneDemande_de_Livraison) {
    echo "<tr>";
    echo "<td>".$uneDemande_de_Livraison['num_demande']."</td>";
    echo "<td>".$uneDemande_de_Livraison['quantite_a_livrer']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=4&action=sup&num_demande=".$uneDemande_de_Livraison['num_demande']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=4&action=edit&num_demande=".$uneDemande_de_Livraison['num_demande']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>