<h3> Ajout d'une matiere premiere </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom de la matiere premiere </td>
			<td><input type="text" name="nom" value="<?=($laMatierePremiere !=null)?$laMatierePremiere['nom']: '' ?>"></td>
		</tr>
		<tr>
			<td> Le fournisseur </td>
			<td>
			<select name="num_fournisseur">
				<?php
				foreach($lesFournisseurs as $unFournisseur)
				{
					echo "<option value ='".$unFournisseur['num_fournisseur']."'>";
					echo $unFournisseur['nom']; 
					echo "</option>"; 
				}
				?>
			</select>

			</td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($laMatierePremiere !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="code_matiere" value ="
<?= ($laMatierePremiere!=null)? $laMatierePremiere['code_matiere']:''?>
">
	</table>
</form>