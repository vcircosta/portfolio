	
	<h3> Liste des clients </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Id client </td>
         <td> Nom </td>
         <td> Mail </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesClients as $unClient) {
    echo "<tr>";
    echo "<td>".$unClient['idclient']."</td>";
    echo "<td>".$unClient['nom']."</td>";
    echo "<td>".$unClient['mail']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=2&action=sup&idclient=".$unClient['idclient']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=2&action=edit&idclient=".$unClient['idclient']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>