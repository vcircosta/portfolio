
	<h3> Liste des ordres des fabrications </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Numéro d'ordre </td>
         <td> Nom </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesOrdres_de_Fabrications as $unOrdre_de_Fabrication) {
    echo "<tr>";
    echo "<td>".$unOrdre_de_Fabrication['num_ordres']."</td>";
    echo "<td>".$unOrdre_de_Fabrication['nom']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=9&action=sup&num_ordres=".$unOrdre_de_Fabrication['num_ordres']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=9&action=edit&num_ordres=".$unOrdre_de_Fabrication['num_ordres']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>