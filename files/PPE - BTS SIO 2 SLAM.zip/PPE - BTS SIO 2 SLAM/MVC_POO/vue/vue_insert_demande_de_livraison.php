<h3> Ajout d'une demande de livraison </h3>
<form method="post">
	<table>
		<tr>
			<td> Quantité à livrer </td>
			<td><input type="text" name="quantite_a_livrer" value="<?= ($laDemande_de_livraison !=null) ? $laDemande_de_livraison ['quantite_a_livrer'] : '' ?>"></td>
		</tr>
		<td> Le numéro d'ordre </td>
			<td>
			<select name="num_ordres">
				<?php 
				foreach($lesOrdres_de_Fabrications as $unOrdre_de_Fabrication)
				{
					echo "<option value ='".$unOrdre_de_Fabrication['num_ordres']."'>";
					echo $unOrdre_de_Fabrication['nom']; 
					echo "</option>"; 
				}
				?>
			</select>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($laDemande_de_livraison !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>     
		</tr>
<input type="hidden" name="num_demande" value ="
<?= ($laDemande_de_livraison !=null)? $laDemande_de_livraison['num_demande'] : '' ?>
">
	</table>
</form>