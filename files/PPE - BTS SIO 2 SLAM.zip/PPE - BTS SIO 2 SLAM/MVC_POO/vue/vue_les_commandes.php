
	<h3> Liste des commandes </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Numéro de commande </td>
         <td> Livraison effective </td>
         <td> Etats des commandes </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesCommandes as $uneCommande) {
    echo "<tr>";
    echo "<td>".$uneCommande['num_commande']."</td>";
    echo "<td>".$uneCommande['livraison_effective']."</td>";
    echo "<td>".$uneCommande['etat_commande']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=3&action=sup&num_commande=".$uneCommande['num_commande']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=3&action=edit&num_commande=".$uneCommande['num_commande']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>