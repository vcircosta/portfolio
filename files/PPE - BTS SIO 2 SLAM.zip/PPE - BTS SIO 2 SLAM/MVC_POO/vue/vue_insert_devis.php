<h3> Ajout d'un devis </h3>
<form method="post">
	<table>
		<tr>
			<td> Description du devis </td>
			<td><input type="text" name="description_devis" value="<?= ($leDevis !=null) ? $leDevis ['description_devis'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Intitule du devis </td>
			<td><input type="text" name="intitule_devis"value="<?= ($leDevis !=null) ? $leDevis ['intitule_devis'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Date du devis </td>
			<td><input type="text" name="date_devis"value="<?= ($leDevis !=null) ? $leDevis ['date_devis'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Le client </td>
			<td>
			<select name="idclient">
				<?php
				foreach($lesClients as $unClient)
				{
					echo "<option value ='".$unClient['idclient']."'>";
					echo $unClient['nom']; 
					echo "</option>"; 
				}
				?>
			</select>

			</td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leDevis !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="reference_devis" value ="
<?= ($leDevis !=null)? $leDevis['reference_devis'] : '' ?>
">
	</table>
</form>