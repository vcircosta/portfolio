<h3> Ajout d'un camion </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom du camion </td>
			<td><input type="text" name="nom" value="<?= ($leCamion !=null) ? $leCamion ['nom'] : '' ?>"></td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leCamion !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="num_camion" value ="
<?= ($leCamion !=null)? $leCamion['num_camion'] : '' ?>
">
	</table>
</form>