
	<h3> Liste des devis </h3>

<form method="post">
    Filtrer par : <input type="text" name="mot">
    <input type="submit" name="Filtrer" value="Filtrer">
</form>
<br/><br/>
<table border = '1'>
    <tr> <td> Réference devis </td>
         <td> Descritption devis </td>
         <td> Intitulé devis </td>
         <td> Date devis </td>
         <?php
         if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
         {
          echo "<td> Opérations </td>";
         }
         ?>
    </tr>
<?php
foreach ($lesDevis as $unDevis) {
    echo "<tr>";
    echo "<td>".$unDevis['reference_devis']."</td>";
    echo "<td>".$unDevis['description_devis']."</td>";
    echo "<td>".$unDevis['intitule_devis']."</td>";
    echo "<td>".$unDevis['date_devis']."</td>";
    
    if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
{
    echo "<td>
        <a href='index.php?page=5&action=sup&reference_devis=".$unDevis['reference_devis']."'> <img src= 'images/sup.png' height='40' width='40'> </a>

        <a href='index.php?page=5&action=edit&reference_devis=".$unDevis['reference_devis']."'> <img src= 'images/edit.png' height='40' width='40'> </a>
        </td>
    ";
    echo "</tr>";
}}
?>
</table>
<br/><br/>