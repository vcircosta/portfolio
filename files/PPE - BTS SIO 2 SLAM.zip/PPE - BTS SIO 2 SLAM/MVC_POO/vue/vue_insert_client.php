<h3> Ajout d'un client </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom du client </td>
			<td><input type="text" name="nom" value="<?= ($leClient !=null) ? $leClient ['nom'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Mail du client </td>
			<td><input type="text" name="mail"value="<?= ($leClient !=null) ? $leClient ['mail'] : '' ?>"></td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leClient !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="idclient" value ="
<?= ($leClient !=null)? $leClient['idclient'] : '' ?>
">
	</table>
</form>