<h3> Ajout d'un site </h3>
<form method="post">
	<table>
		<tr>
			<td> Code postal </td>
			<td><input type="text" name="code_postal" value="<?= ($leSite !=null) ? $leSite ['code_postal'] : '' ?>"></td>
		</tr>
        <tr>
			<td> Ville </td>
			<td><input type="text" name="ville" value="<?= ($leSite !=null) ? $leSite ['ville'] : '' ?>"></td>
		</tr>
        <tr>
			<td> Adresse </td>
			<td><input type="text" name="adresse" value="<?= ($leSite !=null) ? $leSite ['adresse'] : '' ?>"></td>
		</tr>
		<tr>
			<td> Le client </td>
			<td>
			<select name="idclient">
				<?php
				foreach($lesClients as $unClient)
				{
					echo "<option value ='".$unClient['idclient']."'>";
					echo $unClient['nom']; 
					echo "</option>"; 
				}
				?>
			</select>

			</td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leSite !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="idsite" value ="
<?= ($leSite !=null)? $leSite['idsite'] : '' ?>
">
	</table>
</form>