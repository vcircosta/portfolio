<h3> Ajout d'un type de produit </h3>
<form method="post">
	<table>
		<tr>
			<td> Nom </td>
			<td><input type="text" name="nom_type" value="<?= ($leType_Produit !=null) ? $leType_Produit ['nom_type'] : '' ?>"></td>
		</tr>
		<tr>
			<td><input type="reset" name="Annuler" value="Annuler"></td>
			<td><input type="submit" 
		<?= ($leType_Produit !=null)? ' name="Modifier" value="Modifier"' : ' name="Valider" value="Valider"' ?>
		>
	</td>
		</tr>
<input type="hidden" name="code_type" value ="
<?= ($leType_Produit !=null)? $leType_Produit['code_type'] : '' ?>
">
	</table>
</form>