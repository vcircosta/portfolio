<?php
class Modele{
    
	private $unPDO; //instance de la classe PDO

	public function __construct ()
		{
			$this->unPDO=null;
			try{
			$this->unPDO = new PDO("mysql:host=localhost;dbname=mon_filelec","root",""); //PHP DATA Object
			}
			catch(PDOException $exp){
				echo "Erreur de connexion à la BDD <br/>"; 
				echo $exp->getMessage(); 
			} 
		}
	/********************** Les clients ***********/
	public function selectAllClients ()
		{
			if($this->unPDO != null){
				//exécuter la requete de selection des clients 
				$requete = "select * from client ; "; 
				//preparation de la requete 
				$select = $this->unPDO->prepare ($requete); 
				//execution de la requete 
				$select->execute(); 
				//extraction des clients 
				$lesClients = $select->fetchAll(); 
				return $lesClients; 
			}else {
				return null; 
			}
		}
	public function insertClient($tab)
	{
		if($this->unPDO != null){
			$requete="insert into client values(null, :nom, :mail); ";
			$donnees = array(":nom"=>$tab['nom'], 
							 ":mail"=>$tab['mail']); 
			$insert = $this->unPDO->prepare($requete); 
			$insert->execute ($donnees); 
		}
	}
	public function selectLikeClient($mot)
	{
		if($this->unPDO != null){
		$requete = "select * from client where 
		nom like :mot or mail like :mot;"; 
		$donnees =array(":mot"=>"%".$mot."%"); 
		$select =$this->unPDO->prepare($requete); 
		$select->execute($donnees); 
		$lesClients = $select->fetchAll(); 
		return $lesClients;
		}
		else {
			return null;
		}
	}
	public function deleteClient($idclient)
	{
		if($this->unPDO != null){
			$requete="delete from client where  
			idclient = :idclient ;";
			$donnees=array(":idclient"=>$idclient); 
			$delete =$this->unPDO->prepare($requete); 
			$delete->execute($donnees); 
		}
	}
	public function updateClient($tab)
	{
		if($this->unPDO != null){
			$requete="update client set nom=:nom,
			 mail =:mail 
			 where idclient = :idclient;"; 
			$donnees=array( ":nom"=>$tab['nom'],
							":mail"=>$tab['mail'],
							":idclient"=>$tab['idclient']
							);
			$update =$this->unPDO->prepare($requete); 
			$update->execute($donnees);
		}
	}
	public function selectWhereClient($idclient)
	{
		if($this->unPDO != null){
			$requete="select * from client where idclient=:idclient;"; 
			$donnees=array(":idclient"=>$idclient); 
			$select =$this->unPDO->prepare($requete); 
			$select->execute($donnees); 
			$unClient=$select->fetch(); //un seul résultat
			return $unClient; 
		}
		else {
			return null;
		}
	}

    /********************** Les sites ***********/
	public function selectAllSites ()
    {
        if($this->unPDO != null){
            //exécuter la requete de selection des sites 
            $requete = "select * from sites ; "; 
            //preparation de la requete 
            $select = $this->unPDO->prepare ($requete); 
            //execution de la requete 
            $select->execute(); 
            //extraction des sites 
            $lesSites = $select->fetchAll(); 
            return $lesSites; 
        }else {
            return null; 
        }
    }
public function insertSite($tab)
{
    if($this->unPDO != null){
        $requete="insert into sites values(null, :code_postal, :ville, :adresse, :idclient); ";
        $donnees = array(":code_postal"=>$tab['code_postal'], 
                         ":ville"=>$tab['ville'],
                         ":adresse"=>$tab['adresse'],
                         ":idclient"=>$tab['idclient']); 
        $insert = $this->unPDO->prepare($requete); 
        $insert->execute ($donnees); 
    }
}
public function selectLikeSite($mot)
{
    if($this->unPDO != null){
    $requete = "select * from sites where 
    code_postal like :mot or ville like :mot or adresse like :mot;"; 
    $donnees =array(":mot"=>"%".$mot."%"); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $lesSites = $select->fetchAll(); 
    return $lesSites;
    }
    else {
        return null;
    }
}
public function deleteSite($idsite)
{
    if($this->unPDO != null){
        $requete="delete from sites where  
        idsite = :idsite ;";
        $donnees=array(":idsite"=>$idsite); 
        $delete =$this->unPDO->prepare($requete); 
        $delete->execute($donnees); 
    }
}
public function updateSite($tab)
{
    if($this->unPDO != null){
        $requete="update sites set code_postal=:code_postal,
         ville =:ville, adresse =:adresse 
         where idsite = :idsite;"; 
        $donnees=array( ":code_postal"=>$tab['code_postal'],
                        ":ville"=>$tab['ville'],
                        ":adresse"=>$tab['adresse'],
                        ":idsite"=>$tab['idsite']
                        );
        $update =$this->unPDO->prepare($requete); 
        $update->execute($donnees);
    }
}
public function selectWhereSite($idsite)
{
    if($this->unPDO != null){
        $requete="select * from sites where idsite=:idsite;"; 
        $donnees=array(":idsite"=>$idsite); 
        $select =$this->unPDO->prepare($requete); 
        $select->execute($donnees); 
        $unSite=$select->fetch(); //un seul résultat
        return $unSite; 
    }
    else {
        return null;
    }
}
	
    /********************** Les devis ***********/
	public function selectAllDevis ()
    {
        if($this->unPDO != null){
            //exécuter la requete de selection des devis 
            $requete = "select * from devis ; "; 
            //preparation de la requete 
            $select = $this->unPDO->prepare ($requete); 
            //execution de la requete 
            $select->execute(); 
            //extraction des devis 
            $lesDevis = $select->fetchAll(); 
            return $lesDevis; 
        }else {
            return null; 
        }
    }
public function insertDevis($tab)
{
    if($this->unPDO != null){
        $requete="insert into devis values(null, :description_devis, :intitule_devis, :date_devis, :idclient); ";
        $donnees = array(":description_devis"=>$tab['description_devis'], 
                         ":intitule_devis"=>$tab['intitule_devis'],
                         ":date_devis"=>$tab['date_devis'],
                         ":idclient"=>$tab['idclient']); 
        $insert = $this->unPDO->prepare($requete); 
        $insert->execute ($donnees); 
    }
}
public function selectLikeDevis($mot)
{
    if($this->unPDO != null){
    $requete = "select * from devis where 
    description_devis like :mot or intitule_devis like :mot or date_devis like :mot;"; 
    $donnees =array(":mot"=>"%".$mot."%"); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $lesDevis = $select->fetchAll(); 
    return $lesDevis;
    }
    else {
        return null;
    }
}
public function deleteDevis($iddevis)
{
    if($this->unPDO != null){
        $requete="delete from devis where  
        reference_devis = :reference_devis ;";
        $donnees=array(":reference_devis"=>$iddevis); 
        $delete =$this->unPDO->prepare($requete); 
        $delete->execute($donnees); 
    }
}
public function updateDevis($tab)
{
    if($this->unPDO != null){
        $requete="update devis set description_devis=:description_devis,
        intitule_devis =:intitule_devis, date_devis =:date_devis 
         where reference_devis = :reference_devis;"; 
        $donnees=array( ":description_devis"=>$tab['description_devis'],
                        ":intitule_devis"=>$tab['intitule_devis'],
                        ":date_devis"=>$tab['date_devis'],
                        ":reference_devis"=>$tab['reference_devis']
                        );
        $update =$this->unPDO->prepare($requete); 
        $update->execute($donnees);
    }
}
public function selectWhereDevis($iddevis)
{
    if($this->unPDO != null){
        $requete="select * from devis where reference_devis=:reference_devis;"; 
        $donnees=array(":reference_devis"=>$iddevis); 
        $select =$this->unPDO->prepare($requete); 
        $select->execute($donnees); 
        $unDevis=$select->fetch(); //un seul résultat
        return $unDevis; 
    }
    else {
        return null;
    }
}

 /********************** Les commandes ***********/
 public function selectAllCommandes ()
 {
     if($this->unPDO != null){
         //exécuter la requete de selection des commandes
         $requete = "select * from commande ; "; 
         //preparation de la requete 
         $select = $this->unPDO->prepare ($requete); 
         //execution de la requete 
         $select->execute(); 
         //extraction des commandes 
         $lesCommandes = $select->fetchAll(); 
         return $lesCommandes; 
     }else {
         return null; 
     }
 }
public function insertCommande($tab)
{
 if($this->unPDO != null){
     $requete="insert into commande values (null, :livraison_effective, :etat_commande, :reference_devis);";
     $donnees = array(":livraison_effective"=>$tab['livraison_effective'], 
                      ":etat_commande"=>$tab['etat_commande'],
                      ":reference_devis"=>$tab['reference_devis']); 
     $insert = $this->unPDO->prepare($requete); 
     $insert->execute ($donnees); 
 }
}
public function selectLikeCommande($mot)
{
 if($this->unPDO != null){
 $requete = "select * from commande where livraison_effective like :mot or etat_commande like :mot;"; 
 $donnees =array(":mot"=>"%".$mot."%"); 
 $select =$this->unPDO->prepare($requete); 
 $select->execute($donnees); 
 $lesCommandes = $select->fetchAll(); 
 return $lesCommandes;
 }
 else {
     return null;
 }
}
public function deleteCommande($idcommande)
{
 if($this->unPDO != null){
     $requete="delete from commande where  
     num_commande = :num_commande ;";
     $donnees=array(":num_commande"=>$idcommande); 
     $delete =$this->unPDO->prepare($requete); 
     $delete->execute($donnees); 
 }
}
public function updateCommande($tab)
{
 if($this->unPDO != null){
     $requete="update commande set livraison_effective=:livraison_effective,
     etat_commande =:etat_commande where num_commande =:num_commande;"; 
     $donnees=array( ":livraison_effective"=>$tab['livraison_effective'],
                     ":etat_commande"=>$tab['etat_commande'],
                     ":num_commande"=>$tab['num_commande']
                     );
     $update =$this->unPDO->prepare($requete); 
     $update->execute($donnees);
 }
}
public function selectWhereCommande($idcommande)
{
 if($this->unPDO != null){
     $requete="select * from commande where num_commande=:num_commande;"; 
     $donnees=array(":num_commande"=>$idcommande); 
     $select =$this->unPDO->prepare($requete); 
     $select->execute($donnees); 
     $uneCommande=$select->fetch(); //un seul résultat
     return $uneCommande; 
 }
 else {
     return null;
 }
}

/********************** Les type_produit ***********/
public function selectAllTypes_Produits ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des types_produits
        $requete = "select * from typeProduit ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des types_produits 
        $lesTypes_Produits = $select->fetchAll(); 
        return $lesTypes_Produits; 
    }else {
        return null; 
    }
}
public function insertType_Produit($tab)
{
if($this->unPDO != null){
    $requete="insert into typeProduit values(null, :nom_type);";
    $donnees = array(":nom_type"=>$tab['nom_type']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeType_Produit($mot)
{
if($this->unPDO != null){
$requete = "select * from typeProduit where 
nom_type like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesTypes_Produits = $select->fetchAll(); 
return $lesTypes_Produits;
}
else {
    return null;
}
}
public function deleteType_Produit($idtype_produit)
{
if($this->unPDO != null){
    $requete="delete from typeProduit where  
    code_type = :code_type;";
    $donnees=array(":code_type"=>$idtype_produit); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateType_Produit($tab)
{
if($this->unPDO != null){
    $requete="update typeProduit set nom_type=:nom_type
     where code_type = :code_type;"; 
    $donnees=array( ":nom_type"=>$tab['nom_type'],
                    ":code_type"=>$tab['code_type']);
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereType_Produit($idtype_produit)
{
if($this->unPDO != null){
    $requete="select * from typeProduit where code_type = :code_type;"; 
    $donnees=array(":code_type"=>$idtype_produit); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $unType_Produit=$select->fetch(); //un seul résultat
    return $unType_Produit; 
}
else {
    return null;
}
}

/********************** Les produit ***********/
public function selectAllProduits ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des produits
        $requete = "select * from produit ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des produits 
        $lesProduits = $select->fetchAll(); 
        return $lesProduits; 
    }else {
        return null; 
    }
}
public function insertProduit($tab)
{
if($this->unPDO != null){
    $requete="insert into produit values(null, :caracteristique, :code_type); ";
    $donnees = array(":caracteristique"=>$tab['caracteristique'],
                    ":code_type"=>$tab['code_type']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeProduit($mot)
{
if($this->unPDO != null){
$requete = "select * from produit where 
caracteristique like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesProduits = $select->fetchAll(); 
return $lesProduits;
}
else {
    return null;
}
}
public function deleteProduit($idproduit)
{
if($this->unPDO != null){
    $requete="delete from produit where  
    ref_prod = :ref_prod ;";
    $donnees=array(":ref_prod"=>$idproduit); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateProduit($tab)
{
if($this->unPDO != null){
    $requete="update produit set caracteristique=:caracteristique
     where ref_prod = :ref_prod;"; 
    $donnees=array( ":caracteristique"=>$tab['caracteristique'],
                    ":ref_prod"=>$tab['ref_prod']
                    );
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereProduit($idproduit)
{
if($this->unPDO != null){
    $requete="select * from produit where ref_prod = :ref_prod;"; 
    $donnees=array(":ref_prod"=>$idproduit); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $unProduit=$select->fetch(); //un seul résultat
    return $unProduit; 
}
else {
    return null;
}
}

/********************** Les fournisseurs ***********/
public function selectAllFournisseurs ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des fournisseurs
        $requete = "select * from fournisseur ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des fournisseurs 
        $lesFournisseurs = $select->fetchAll(); 
        return $lesFournisseurs; 
    }else {
        return null; 
    }
}
public function insertFournisseur($tab)
{
if($this->unPDO != null){
    $requete="insert into fournisseur values(null, :nom); ";
    $donnees = array(":nom"=>$tab['nom']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeFournisseur($mot)
{
if($this->unPDO != null){
$requete = "select * from fournisseur where 
nom like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesFournisseurs = $select->fetchAll(); 
return $lesFournisseurs;
}
else {
    return null;
}
}
public function deleteFournisseur($idfournisseur)
{
if($this->unPDO != null){
    $requete="delete from fournisseur where  
    num_fournisseur = :num_fournisseur ;";
    $donnees=array(":num_fournisseur"=>$idfournisseur); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateFournisseur($tab)
{
if($this->unPDO != null){
    $requete="update fournisseur set nom=:nom
     where num_fournisseur = :num_fournisseur;"; 
    $donnees=array( ":nom"=>$tab['nom'],
                    ":num_fournisseur"=>$tab['num_fournisseur']
                    );
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereFournisseur($idfournisseur)
{
if($this->unPDO != null){
    $requete="select * from fournisseur where num_fournisseur = :num_fournisseur;"; 
    $donnees=array(":num_fournisseur"=>$idfournisseur); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $unFournisseur=$select->fetch(); //un seul résultat
    return $unFournisseur; 
}
else {
    return null;
}
}

/********************** Les matieres_premieres ***********/
public function selectAllMatieres_Premieres ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des matieres premieres
        $requete = "select * from matierePremire ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des matieres premieres 
        $lesMatieresPremieres = $select->fetchAll(); 
        return $lesMatieresPremieres; 
    }else {
        return null; 
    }
}
public function insertMatiere_Premiere($tab)
{
if($this->unPDO != null){
    $requete="insert into matierePremire values(null, :nom, :num_fournisseur); ";
    $donnees = array(":nom"=>$tab['nom'],
                    ":num_fournisseur"=>$tab['num_fournisseur']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeMatiere_Premiere($mot)
{
if($this->unPDO != null){
$requete = "select * from matierePremire where 
nom like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesMatieresPremieres = $select->fetchAll(); 
return $lesMatieresPremieres;
}
else {
    return null;
}
}
public function deleteMatiere_Premiere($idmatiere_premiere)
{
if($this->unPDO != null){
    $requete="delete from matierePremire where  
    code_matiere = :code_matiere ;";
    $donnees=array(":code_matiere"=>$idmatiere_premiere); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateMatiere_Premiere($tab)
{
if($this->unPDO != null){
    $requete="update matierePremire set nom=:nom
     where code_matiere = :code_matiere;"; 
    $donnees=array( ":nom"=>$tab['nom'],
                    ":code_matiere"=>$tab['code_matiere']
                    );
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereMatiere_Premiere($idmatiere_premiere)
{
if($this->unPDO != null){
    $requete="select * from matierePremire where code_matiere = :code_matiere;"; 
    $donnees=array(":code_matiere"=>$idmatiere_premiere); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $uneMatierePremiere=$select->fetch(); //un seul résultat
    return $uneMatierePremiere; 
}
else {
    return null;
}
}

/********************** Les ordres de fabrication ***********/
public function selectAllOrdres_de_Fabrications ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des ordres de fabrications
        $requete = "select * from ordreDeFabrication ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des ordres de fabrications
        $lesOrdres_de_Fabrications = $select->fetchAll(); 
        return $lesOrdres_de_Fabrications; 
    }else {
        return null; 
    }
}
public function insertOrdre_de_Fabrication($tab)
{
if($this->unPDO != null){
    $requete="insert into ordreDeFabrication values(null, :nom, :idclient); ";
    $donnees = array(":nom"=>$tab['nom'],
                    ":idclient"=>$tab['idclient']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeOrdre_de_Fabrication($mot)
{
if($this->unPDO != null){
$requete = "select * from ordreDeFabrication where 
nom like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesOrdres_de_Fabrications = $select->fetchAll(); 
return $lesOrdres_de_Fabrications;
}
else {
    return null;
}
}
public function deleteOrdre_de_Fabrication($idordres_de_fabrication)
{
if($this->unPDO != null){
    $requete="delete from ordreDeFabrication where  
    num_ordres = :num_ordres ;";
    $donnees=array(":num_ordres"=>$idordres_de_fabrication); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateOrdre_de_Fabrication($tab)
{
if($this->unPDO != null){
    $requete="update ordreDeFabrication set nom=:nom
     where num_ordres = :num_ordres;"; 
    $donnees=array( ":nom"=>$tab['nom'],
                    ":num_ordres"=>$tab['num_ordres']
                    );
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereOrdre_de_Fabrication($idordres_de_fabrication)
{
if($this->unPDO != null){
    $requete="select * from ordreDeFabrication where num_ordres = :num_ordres;"; 
    $donnees=array(":num_ordres"=>$idordres_de_fabrication); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $unOrdre_de_Fabrication=$select->fetch(); //un seul résultat
    return $unOrdre_de_Fabrication; 
}
else {
    return null;
}
}

/********************** Les camions ***********/
public function selectAllCamions ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des camions
        $requete = "select * from camion ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des camions
        $lesCamions = $select->fetchAll(); 
        return $lesCamions; 
    }else {
        return null; 
    }
}
public function insertCamion($tab)
{
if($this->unPDO != null){
    $requete="insert into camion values(null, :nom); ";
    $donnees = array(":nom"=>$tab['nom']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeCamion($mot)
{
if($this->unPDO != null){
$requete = "select * from camion where 
nom like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesCamions = $select->fetchAll(); 
return $lesCamions;
}
else {
    return null;
}
}
public function deleteCamion($idcamion)
{
if($this->unPDO != null){
    $requete="delete from camion where  
    num_camion = :num_camion ;";
    $donnees=array(":num_camion"=>$idcamion); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateCamion($tab)
{
if($this->unPDO != null){
    $requete="update camion set nom=:nom
     where num_camion = :num_camion;"; 
    $donnees=array( ":nom"=>$tab['nom'],
                    ":num_camion"=>$tab['num_camion']
                    );
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereCamion($idcamion)
{
if($this->unPDO != null){
    $requete="select * from camion where num_camion = :num_camion;"; 
    $donnees=array(":num_camion"=>$idcamion); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $unCamion=$select->fetch(); //un seul résultat
    return $unCamion; 
}
else {
    return null;
}
}

/********************** Les lots de livraisons ***********/
public function selectAllLots_de_Livraisons ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des lots de livraisons
        $requete = "select * from lotDeLivraison ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des lots de livraisons
        $lesLots_de_Livraisons = $select->fetchAll(); 
        return $lesLots_de_Livraisons; 
    }else {
        return null; 
    }
}
public function insertLot_de_Livraison($tab)
{
if($this->unPDO != null){
    $requete="insert into lotDeLivraison values(null, :quantite_du_lot , :date_de_fabrication , :date_du_depart , :date_de_livraison, :num_demande); ";
    $donnees = array(":quantite_du_lot"=>$tab['quantite_du_lot'],
                    ":date_de_fabrication"=>$tab['date_de_fabrication'],
                    ":date_du_depart"=>$tab['date_du_depart'],
                    ":date_de_livraison"=>$tab['date_de_livraison'],
                    ":num_demande"=>$tab['num_demande']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeLot_de_Livraison($mot)
{
if($this->unPDO != null){
$requete = "select * from lotDeLivraison where 
quantite_du_lot like :mot or date_de_fabrication like :mot or date_du_depart like :mot or date_de_livraison like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesLots_de_Livraisons = $select->fetchAll(); 
return $lesLots_de_Livraisons;
}
else {
    return null;
}
}
public function deleteLot_de_Livraison($idlot_de_livraison)
{
if($this->unPDO != null){
    $requete="delete from lotDeLivraison where  
    numero_lot = :numero_lot ;";
    $donnees=array(":numero_lot"=>$idlot_de_livraison); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateLot_de_Livraison($tab)
{
if($this->unPDO != null){
    $requete="update lotDeLivraison set quantite_du_lot=:quantite_du_lot, date_de_fabrication=:date_de_fabrication ,date_du_depart=:date_du_depart,date_de_livraison=:date_de_livraison
     where numero_lot = :numero_lot;"; 
    $donnees=array( ":quantite_du_lot"=>$tab['quantite_du_lot'],
                    ":date_de_fabrication"=>$tab['date_de_fabrication'],
                    ":date_du_depart"=>$tab['date_du_depart'],
                    ":date_de_livraison"=>$tab['date_de_livraison'],
                    ":numero_lot"=>$tab['numero_lot']
                    );
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereLot_de_Livraison($idlot_de_livraison)
{
if($this->unPDO != null){
    $requete="select * from lotDeLivraison where numero_lot = :numero_lot;"; 
    $donnees=array(":numero_lot"=>$idlot_de_livraison); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $unLot_de_Livraison=$select->fetch(); //un seul résultat
    return $unLot_de_Livraison; 
}
else {
    return null;
}
}

/********************** Les demandes de livraisons ***********/
public function selectAllDemandes_de_Livraisons ()
{
    if($this->unPDO != null){
        //exécuter la requete de selection des demandes de livraisons
        $requete = "select * from demandeDeLivraison ; "; 
        //preparation de la requete 
        $select = $this->unPDO->prepare ($requete); 
        //execution de la requete 
        $select->execute(); 
        //extraction des demandes de livraisons
        $lesDemandes_de_Livraisons = $select->fetchAll(); 
        return $lesDemandes_de_Livraisons; 
    }else {
        return null; 
    }
}
public function insertDemande_de_Livraison($tab)
{
if($this->unPDO != null){
    $requete="insert into demandeDeLivraison values(null, :quantite_a_livrer, :num_ordres);";
    $donnees = array(":quantite_a_livrer"=>$tab['quantite_a_livrer'],
                    ":num_ordres"=>$tab['num_ordres']); 
    $insert = $this->unPDO->prepare($requete); 
    $insert->execute ($donnees); 
}
}
public function selectLikeDemande_de_Livraison($mot)
{
if($this->unPDO != null){
$requete = "select * from demandeDeLivraison where quantite_a_livrer like :mot;"; 
$donnees =array(":mot"=>"%".$mot."%"); 
$select =$this->unPDO->prepare($requete); 
$select->execute($donnees); 
$lesDemandes_de_Livraisons = $select->fetchAll(); 
return $lesDemandes_de_Livraisons;
}
else {
    return null;
}
}
public function deleteDemande_de_Livraison($iddemande_de_livraison)
{
if($this->unPDO != null){
    $requete="delete from demandeDeLivraison where  
    num_demande = :num_demande ;";
    $donnees=array(":num_demande"=>$iddemande_de_livraison); 
    $delete =$this->unPDO->prepare($requete); 
    $delete->execute($donnees); 
}
}
public function updateDemande_de_Livraison($tab)
{
if($this->unPDO != null){
    $requete="update demandeDeLivraison set quantite_a_livrer=:quantite_a_livrer where num_demande=:num_demande;";
    $donnees=array(":quantite_a_livrer"=>$tab['quantite_a_livrer'],
                    ":num_demande"=>$tab['num_demande']);
    $update =$this->unPDO->prepare($requete); 
    $update->execute($donnees);
}
}
public function selectWhereDemande_de_Livraison($iddemande_de_livraison)
{
if($this->unPDO != null){
    $requete="select * from demandeDeLivraison where num_demande=:num_demande;"; 
    $donnees=array(":num_demande"=>$iddemande_de_livraison); 
    $select =$this->unPDO->prepare($requete); 
    $select->execute($donnees); 
    $uneDemande_de_Livraison=$select->fetch(); //un seul résultat 
    return $uneDemande_de_Livraison; 
}
else {
    return null;
}
}

public function verifConnexion($email, $mdp)
	{
		if ($this->unPDO != null) {
			$requete = "select * from user where email = :email and mdp = :mdp;";
			$donnees = array(":email" => $email, ":mdp" => $mdp);
			$select = $this->unPDO->prepare($requete);
			$select->execute($donnees);
			$unUser = $select->fetch();
			return $unUser;
		} else {
			return null;
		}
	}
}
?>

















