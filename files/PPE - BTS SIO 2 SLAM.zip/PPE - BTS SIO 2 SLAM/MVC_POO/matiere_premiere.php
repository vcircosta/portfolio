<h2> Gestion des matieres premieres </h2>

<?php
	$lesFournisseurs = $unControleur->selectAllFournisseurs ();
	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$laMatierePremiere = null;
	if (isset($_GET['action']) && isset($_GET['code_matiere'])){
		$action = $_GET['action'];
		$idmatiere_premiere = $_GET['code_matiere'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteMatiere_Premiere($idmatiere_premiere); break;
			case 'edit': $laMatierePremiere = $unControleur -> selectWhereMatiere_Premiere($idmatiere_premiere);
			break;

		}
	}
	

	require_once ("vue/vue_insert_matiere_premiere.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertMatiere_Premiere($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateMatiere_Premiere($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesMatieresPremieres = $unControleur -> selectLikeMatiere_Premiere($mot);
	}else {
		$lesMatieresPremieres = $unControleur->selectAllMatieres_Premieres ();
	}
	require_once ("vue/vue_les_matieres_premieres.php");
?>