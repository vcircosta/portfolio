<h2> Gestion des demandes de livraisons </h2>

<?php
	$lesOrdres_de_Fabrications = $unControleur->selectAllOrdres_de_Fabrications ();
	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$laDemande_de_livraison = null;
	if (isset($_GET['action']) && isset($_GET['num_demande'])){
		$action = $_GET['action'];
		$iddemande_de_livraison = $_GET['num_demande'];
		switch ($action) 
		{
			case 'sup': $unControleur->deleteDemande_de_Livraison($iddemande_de_livraison); break;
			case 'edit': $laDemande_de_Livraison=$unControleur->selectWhereDemande_de_Livraison($iddemande_de_livraison);
			break;

		}
	}

	require_once ("vue/vue_insert_demande_de_livraison.php");
	if (isset($_POST['Valider']))
	{
		$unControleur ->insertDemande_de_Livraison($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur ->updateDemande_de_Livraison($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesDemandes_de_Livraisons = $unControleur ->selectLikeDemande_de_Livraison($mot);
	}else {
		$lesDemandes_de_Livraisons = $unControleur->selectAllDemandes_de_Livraisons ();
	}
	require_once ("vue/vue_les_demandes_de_livraisons.php");
?>