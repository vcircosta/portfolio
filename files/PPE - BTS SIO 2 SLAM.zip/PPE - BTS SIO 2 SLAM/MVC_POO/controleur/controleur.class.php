<?php
	require_once ("modele/modele.class.php");
	class Controleur
	{
		private $unModele;

		public function __construct(){
			$this->unModele = new Modele();
		}
		/******Les camions******/
		public function selectAllCamions (){
			$lesCamions = $this->unModele->selectAllCamions();
			return $lesCamions;
		}
		public function insertCamion ($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertCamion($tab);
		}
		public function selectLikeCamion($mot)
		{
			$lesCamions = $this->unModele->selectLikeCamion($mot);
			return $lesCamions;
		}
		public function deleteCamion($idcamion)
		{
			$this->unModele->deleteCamion($idcamion);
		}
		public function updateCamion($tab)
		{
			$this->unModele->updateCamion($tab);
		}
		public function selectWhereCamion($idcamion)
		{
			return $this->unModele->selectWhereCamion($idcamion);
		}

        /* Les Clients  */
        public function selectAllClients (){
			$lesClients = $this->unModele->selectAllClients();
			return $lesClients;
		}
		public function insertClient ($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertClient($tab);
		}
		public function selectLikeClient($mot)
		{
			$lesClients = $this->unModele->selectLikeClient($mot);
			return $lesClients;
		}
		public function deleteClient($idclient)
		{
			$this->unModele->deleteClient($idclient);
		}
		public function updateClient($tab)
		{
			$this->unModele->updateClient($tab);
		}
		public function selectWhereClient($idclient)
		{
			return $this->unModele->selectWhereClient($idclient);
		}

        /* Les Commandes */
        public function selectAllCommandes (){
			$lesCommandes = $this->unModele->selectAllCommandes();
			return $lesCommandes;
		}
		public function insertCommande($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertCommande($tab);
		}
		public function selectLikeCommande($mot)
		{
			$lesCommandes = $this->unModele->selectLikeCommande($mot);
			return $lesCommandes;
		}
		public function deleteCommande($idcommande)
		{
			$this->unModele->deleteCommande($idcommande);
		}
		public function updateCommande($tab)
		{
			$this->unModele->updateCommande($tab);
		}
		public function selectWhereCommande($idcommande)
		{
			return $this->unModele->selectWhereCommande($idcommande);
		}

        /* Les Demandes de Livraisons */
		public function selectAllDemandes_de_Livraisons (){
			$lesDemandes_de_Livraisons = $this->unModele->selectAllDemandes_de_Livraisons();
			return $lesDemandes_de_Livraisons;
		}
		public function insertDemande_de_Livraison ($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertDemande_de_Livraison($tab);
		}
		public function selectLikeDemande_de_Livraison($mot)
		{
			$lesDemandes_de_Livraisons = $this->unModele->selectLikeDemande_de_Livraison($mot);
			return $lesDemandes_de_Livraisons;
		}
		public function deleteDemande_de_Livraison($iddemande_de_livraison)
		{
			$this->unModele->deleteDemande_de_Livraison($iddemande_de_livraison);
		}
		public function updateDemande_de_Livraison($tab)
		{
			$this->unModele->updateDemande_de_Livraison($tab);
		}
		public function selectWhereDemande_de_Livraison($iddemande_de_livraison)
		{
			return $this->unModele->selectWhereDemande_de_Livraison($iddemande_de_livraison);
		}

        /* Les Devis  */
		public function selectAllDevis (){
			$lesDevis = $this->unModele->selectAllDevis();
			return $lesDevis;
		}
		public function insertDevis ($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertDevis($tab);
		}
		public function selectLikeDevis($mot)
		{
			$lesDevis = $this->unModele->selectLikeDevis($mot);
			return $lesDevis;
		}
		public function deleteDevis($iddevis)
		{
			$this->unModele->deleteDevis($iddevis);
		}
		public function updateDevis($tab)
		{
			$this->unModele->updateDevis($tab);
		}
		public function selectWhereDevis($iddevis)
		{
			return $this->unModele->selectWhereDevis($iddevis);
		}

        /* Les Fournisseurs  */
		public function selectAllFournisseurs (){
			$lesFournisseurs = $this->unModele->selectAllFournisseurs();
			return $lesFournisseurs;
		}
		public function insertFournisseur ($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertFournisseur($tab);
		}
		public function selectLikeFournisseur($mot)
		{
			$lesFournisseurs = $this->unModele->selectLikeFournisseur($mot);
			return $lesFournisseurs;
		}
		public function deleteFournisseur($idfournisseur)
		{
			$this->unModele->deleteFournisseur($idfournisseur);
		}
		public function updateFournisseur($tab)
		{
			$this->unModele->updateFournisseur($tab);
		}
		public function selectWhereFournisseur($idfournisseur)
		{
			return $this->unModele->selectWhereFournisseur($idfournisseur);
		}

        /* Les Lots de Livraisons */
		public function selectAllLots_de_Livraisons (){
			$lesLots_de_Livraisons = $this->unModele->selectAllLots_de_Livraisons();
			return $lesLots_de_Livraisons;
		}
		public function insertLot_de_Livraison ($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertLot_de_Livraison($tab);
		}
		public function selectLikeLot_de_Livraison($mot)
		{
			$lesLots_de_Livraisons = $this->unModele->selectLikeLot_de_Livraison($mot);
			return $lesLots_de_Livraisons;
		}
		public function deleteLot_de_Livraison($idlot_de_livraison)
		{
			$this->unModele->deleteLot_de_Livraison($idlot_de_livraison);
		}
		public function updateLot_de_Livraison($tab)
		{
			$this->unModele->updateLot_de_Livraison($tab);
		}
		public function selectWhereLot_de_Livraison($idlot_de_livraison)
		{
			return $this->unModele->selectWhereLot_de_Livraison($idlot_de_livraison);
		}

        /* Les Matieres Premieres */
		public function selectAllMatieres_Premieres (){
			$lesMatieresPremieres = $this->unModele->selectAllMatieres_Premieres();
			return $lesMatieresPremieres;
		}
		public function insertMatiere_Premiere ($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertMatiere_Premiere($tab);
		}
		public function selectLikeMatiere_Premiere($mot)
		{
			$lesMatieresPremieres = $this->unModele->selectLikeMatiere_Premiere($mot);
			return $lesMatieresPremieres;
		}
		public function deleteMatiere_Premiere($idmatiere_premiere)
		{
			$this->unModele->deleteMatiere_Premiere($idmatiere_premiere);
		}
		public function updateMatiere_Premiere($tab)
		{
			$this->unModele->updateMatiere_Premiere($tab);
		}
		public function selectWhereMatiere_Premiere($idmatiere_premiere)
		{
			return $this->unModele->selectWhereMatiere_Premiere($idmatiere_premiere);
		}

        /* Les Ordres de fabrications */
		public function selectAllOrdres_de_Fabrications(){
			$lesOrdres_de_Fabrications = $this->unModele->selectAllOrdres_de_Fabrications();
			return $lesOrdres_de_Fabrications;
		}
		public function insertOrdre_de_Fabrication($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertOrdre_de_Fabrication($tab);
		}
		public function selectLikeOrdre_de_Fabrication($mot)
		{
			$lesOrdres_de_Fabrications = $this->unModele->selectLikeOrdre_de_Fabrication($mot);
			return $lesOrdres_de_Fabrications;
		}
		public function deleteOrdre_de_Fabrication($idordre_de_fabrication)
		{
			$this->unModele->deleteOrdre_de_Fabrication($idordre_de_fabrication);
		}
		public function updateOrdre_de_Fabrication($tab)
		{
			$this->unModele->updateOrdre_de_Fabrication($tab);
		}
		public function selectWhereOrdre_de_Fabrication($idordre_de_fabrication)
		{
			return $this->unModele->selectWhereOrdre_de_Fabrication($idordre_de_fabrication);
		}

        /* Les Produits */
		public function selectAllProduits(){
			$lesProduits = $this->unModele->selectAllProduits();
			return $lesProduits;
		}
		public function insertProduit($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertProduit($tab);
		}
		public function selectLikeProduit($mot)
		{
			$lesProduits = $this->unModele->selectLikeProduit($mot);
			return $lesProduits;
		}
		public function deleteProduit($idproduit)
		{
			$this->unModele->deleteProduit($idproduit);
		}
		public function updateProduit($tab)
		{
			$this->unModele->updateProduit($tab);
		}
		public function selectWhereProduit($idproduit)
		{
			return $this->unModele->selectWhereProduit($idproduit);
		}

        /* Les Sites */
		public function selectAllSites(){
			$lesSites = $this->unModele->selectAllSites();
			return $lesSites;
		}
		public function insertSite($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertSite($tab);
		}
		public function selectLikeSite($mot)
		{
			$lesSites = $this->unModele->selectLikeSite($mot);
			return $lesSites;
		}
		public function deleteSite($idsite)
		{
			$this->unModele->deleteSite($idsite);
		}
		public function updateSite($tab)
		{
			$this->unModele->updateSite($tab);
		}
		public function selectWhereSite($idsite)
		{
			return $this->unModele->selectWhereSite($idsite);
		}

        /* Les Types Produits */
		public function selectAllTypes_Produits(){
			$lesTypes_Produits = $this->unModele->selectAllTypes_Produits();
			return $lesTypes_Produits;
		}
		public function insertType_Produit($tab)
		{
			//contrôler les données avant de les envoyer au modèle
			$this->unModele->insertType_Produit($tab);
		}
		public function selectLikeType_Produit($mot)
		{
			$lesTypes_Produits = $this->unModele->selectLikeType_Produit($mot);
			return $lesTypes_Produits;
		}
		public function deleteType_Produit($idtype_produit)
		{
			$this->unModele->deleteType_Produit($idtype_produit);
		}
		public function updateType_Produit($tab)
		{
			$this->unModele->updateType_Produit($tab);
		}
		public function selectWhereType_Produit($idtype_produit)
		{
			return $this->unModele->selectWhereType_Produit($idtype_produit);
		}


		/* CONNEXION	*/
		public function verifConnexion($email,$mdp){
			//controler les emials / mdp
			$unUser=$this->unModele->verifConnexion($email, $mdp);
			return $unUser;
		}
	}
?>