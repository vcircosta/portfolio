drop database if exists mon_filelec;
create database mon_filelec;
use mon_filelec;

create table user (
		iduser int(3) not null auto_increment,
		nom varchar(30),
		prenom varchar(30),
		email varchar(50),
		mdp varchar(100),
		role enum ("admin","user"),
		primary key (iduser)
	);

create table client (
    idclient int(3) not null auto_increment,
	nom varchar (50),
	mail varchar (50),
	primary key (idclient)
);

create table sites (
    idsite int(3) not null auto_increment,
	code_postal char (5),
	ville varchar (50),
    adresse varchar (50),
	idclient int(3) not null,
	primary key (idsite),
	foreign key (idclient) references client(idclient)
);

create table devis (
    reference_devis int(3) not null auto_increment,
	description_devis varchar (50),
	intitule_devis varchar (50),
    date_devis varchar(10),
	idclient int(3) not null,
	primary key (reference_devis),	
	foreign key (idclient) references client(idclient)
);

create table commande (
    num_commande int(3) not null auto_increment,
	livraison_effective varchar(10),
	etat_commande varchar (50),
	reference_devis int(3) not null,
	primary key (num_commande),
	foreign key (reference_devis) references devis(reference_devis)
);

create table typeProduit (
    code_type int(3) not null auto_increment,
	nom_type varchar (50),
	primary key (code_type)
);

create table produit (
    ref_prod int(3) not null auto_increment,
	caracteristique varchar(50),
	code_type int(3) not null,
	primary key (ref_prod),
	foreign key (code_type) references typeProduit(code_type)
);

create table fournisseur (
    num_fournisseur int(3) not null auto_increment,
	nom varchar (50),
	primary key (num_fournisseur)
);

create table matierePremire (
    code_matiere int(3) not null auto_increment,
	nom varchar(50),
	num_fournisseur int(3) not null,
	primary key (code_matiere),
	foreign key (num_fournisseur) references fournisseur(num_fournisseur)
);

create table ordreDeFabrication (
    num_ordres int(3) not null auto_increment,
	nom varchar (50),
	idclient int(3) not null,
	primary key (num_ordres),
	foreign key (idclient) references client(idclient)
);

create table camion (
    num_camion int(3) not null auto_increment,
	nom varchar (50),
	primary key (num_camion)
);

create table lotDeLivraison (
    numero_lot int(3) not null auto_increment,
	quantite_du_lot int(5),
	date_de_fabrication varchar(10),
	date_du_depart varchar(10),
	date_de_livraison varchar(10),
	num_demande int(3) not null,
	primary key (numero_lot),
	foreign key (num_demande) references demandeDeLivraison(num_demande)
);

create table demandeDeLivraison (
    num_demande int(3) not null auto_increment,
	quantite_a_livrer int (5),
	num_ordres int(3) not null,
	primary key (num_demande),
	foreign key (num_ordres) references ordreDeFabrication(num_ordres)
);

insert into user VALUES
    (null, "Valentin", "Quentin", "c@gmail.com", "123", "admin"),
    (null, "Prince", "Clara", "d@gmail.com", "456", "user");

insert into client values
	(null, "Client1", "client1@gmail.com"),
	(null, "Client2", "client2@gmail.com");

insert into sites values
	(null, 75017, "PARIS","2 rue D'Avant",1),
	(null, 75018, "PARIS","2 rue D'Apres",2);

insert into devis values
	(null, "achat", "achat fil","2022-12-12",1),
	(null, "achat", "achat cable","2022-12-11",2);

insert into commande values
	(null, "2022-01-03", "en cours",1),
	(null, "2021-04-15", "valide",2);

insert into typeProduit values
	(null, "Fils"),
	(null, "Cables");

insert into produit values
	(null, "12cm",1),
	(null, "15cm",2);

insert into fournisseur values
	(null, "fournisseur1"),
	(null, "fournisseur2");

insert into matierePremire values
	(null, "Metal",1),
	(null, "Verre",2);

insert into ordreDeFabrication values
	(null, "A41",1),
	(null, "B42",2);

insert into camion values
	(null, "Ford"),
	(null, "Renault");

insert into lotDeLivraison values
	(null, "3", "2011-01-01","2022-12-25","2022-12-29",1),
	(null, "7", "2022-12-11","2022-11-18","2022-11-19",2);

insert into demandeDeLivraison values
	(null, "2",1),
	(null, "5",2);




