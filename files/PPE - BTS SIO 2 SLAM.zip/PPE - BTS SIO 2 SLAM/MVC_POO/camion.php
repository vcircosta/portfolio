<h2> Gestion des camions </h2>

<?php

	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$leCamion = null;
	if (isset($_GET['action']) && isset($_GET['num_camion'])){
		$action = $_GET['action'];
		$idcamion = $_GET['num_camion'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteCamion($idcamion); break;
			case 'edit': $leCamion = $unControleur -> selectWhereCamion($idcamion);
			break;

		}
	}
	

	require_once ("vue/vue_insert_camion.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertCamion($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateCamion($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesCamions=$unControleur->selectLikeCamion($mot);
	}else {
		$lesCamions=$unControleur->selectAllCamions();
	}
	require_once ("vue/vue_les_camions.php");
?>
