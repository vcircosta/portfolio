<h2> Gestion des types de produit </h2>

<?php

	if(isset($_SESSION['role']) && $_SESSION['role']=='admin' )
	{
	$leType_Produit = null;
	if (isset($_GET['action']) && isset($_GET['code_type'])){
		$action = $_GET['action'];
		$idtype_produit = $_GET['code_type'];
		switch ($action) 
		{
			case 'sup': $unControleur -> deleteType_Produit($idtype_produit); break;
			case 'edit': $leType_Produit = $unControleur -> selectWhereType_Produit($idtype_produit);
			break;

		}
	}
	

	require_once ("vue/vue_insert_type_produit.php");
	if (isset($_POST['Valider']))
	{
		$unControleur -> insertType_Produit($_POST);
	}

	if (isset($_POST['Modifier']))
	{
		$unControleur -> updateType_Produit($_POST);
	}
}
	if(isset($_POST['Filtrer']))
	{
		$mot = $_POST['mot'];
		$lesTypes_Produits = $unControleur -> selectLikeType_Produit($mot);
	}else {
		$lesTypes_Produits = $unControleur->selectAllTypes_Produits();
	}
	require_once ("vue/vue_les_types_produits.php");
?>