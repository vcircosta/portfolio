drop database if exists mon_filelec;
create database mon_filelec;
use mon_filelec;

create table user (
		iduser int(3) not null auto_increment,
		nom varchar(30),
		prenom varchar(30),
		email varchar(50),
		mdp varchar(100),
		role enum ("admin","user"),
		primary key (iduser)
	);

insert into user VALUES
    (null, "Valentin", "Quentin", "c@gmail.com", "123", "admin"),
    (null, "Prince", "Clara", "d@gmail.com", "456", "user");

create table client (
    idclient int(3) not null auto_increment,
	nom varchar (50),
	prenom varchar(50),
	mail varchar (50),
	adresse varchar(50),
	Code_postal char(5),
	pays varchar(25),
	primary key (idclient)
);

insert into client VALUES
	(null, "Bristol", "Neal" ,"n@gmail.com", "45 rue Paris", "92100","Portugal"),
	(null, "Martin", "Pierre", "p@gmail.com", "35 avenue de Gaulle", "93100","France");


create table typeProduit (
    code_type int(3) not null auto_increment,
	nom_type varchar(50),
	primary key (code_type)
);

insert into typeProduit VALUES
	(null, "Fils"),
	(null, "Cables");

create table produit (
    ref_prod int(3) not null auto_increment,
	caracteristiques varchar(50),
	prix char(3),
	quantite_stock int(10),
    code_type int(3),
	primary key (ref_prod),
    foreign key (code_type) references typeProduit(code_type)
);

insert into produit VALUES
	(null, "Rouge", "125",5,1),
	(null, "Noir",  "150",4,2);

create table fournisseur (
    num_fournisseur int(6) not null auto_increment,
	nom varchar (50),
	prenom varchar(50),
	mail varchar (50),
	adresse varchar(50),
	Code_postal char(5),
	pays varchar(25),
	villes varchar(25),
	primary key (num_fournisseur)
);

insert into fournisseur VALUES
	(null, "Martin", "Olivier", "m@gmail.com", "56 rue de la peur", "79478", "France","Paris"),
	(null, "Dubois", "Thomas",  "d@gmail.com", "67 rue de la pompe", "45684", "Espagnol","Madrid");

create table devis (
	ref_devis int(5) not null auto_increment,
	descrip_devis varchar(100),
	intitule_devis varchar(100),
	date_devis varchar(10), 
	etat varchar(10),
    idclient int(3),
	primary key (ref_devis),
    foreign key (idclient) references client(idclient)
);

insert into devis VALUES
	(null, "achat", "achat fil","12/12/2022","valide",1),
	(null, "achat", "achat cable","12/08/2022","en cours",2);

create table commande_fournisseur (
	ref_commande int(10) not null auto_increment,
	date_livraison varchar(10), 
    num_fournisseur int(3),
	primary key (ref_commande),
    foreign key (num_fournisseur) references fournisseur(num_fournisseur)
);

insert into commande_fournisseur VALUES
	(null, "01/06/2019",1),
	(null, "19/06/20022",2);

    
create table commande (
    num_commande int(3) not null auto_increment,
	etat_commande varchar(50),
	date_commande varchar(10),
    ref_devis int(3),
	primary key (num_commande),
    foreign key (ref_devis) references devis(ref_devis)
);

insert into commande VALUES
	(null, "en cours", "10/03/2022",1),
	(null, "valide", "15/04/2021", 2);












