package vue;

import java.awt.*;
import javax.swing.*;

public class PanelDeBase extends JPanel {
	
	public PanelDeBase(Color uneCouleur) {
		this.setBounds(26, 60, 1290, 340);
		this.setLayout(null);
		this.setBackground(new Color(135, 206, 235));
		this.setVisible(false);
	}

}
